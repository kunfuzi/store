jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"],
  short_month_names: ["Jan", "Feb", "Maa", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"],
  short_day_names: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"]
});
