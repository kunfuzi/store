jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Január", "Február", "Marec", "Apríl", "Máj", "Jún", "Júl", "August", "September", "Október", "November", "December"],
  short_month_names: ["Jan", "Feb", "Mar", "Apr", "Máj", "Jún", "Júl", "Aug", "Sep", "Okt", "Nov", "Dec"],
  short_day_names: ["Ned", "Pon", "Uto", "Str", "Štv", "Pia", "Sob"]
});
