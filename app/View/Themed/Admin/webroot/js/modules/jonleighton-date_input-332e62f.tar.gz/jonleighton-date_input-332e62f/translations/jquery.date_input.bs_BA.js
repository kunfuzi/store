jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["januar", "februar", "mart", "april", "maj", "juni", "juli", "august", "septembar", "oktobar", "novembar", "decembar"],
  short_month_names: ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"],
  short_day_names: ["po", "ut", "sr", "če", "pe", "su", "ne"]
});
