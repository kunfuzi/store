jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"],
  short_month_names: ["Jan", "Fev", "Mar", "Avr", "Mai", "Juin", "Juil", "Aou", "Sep", "Oct", "Nov", "Dec"],
  short_day_names: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"]
});
