jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"],
  short_month_names: ["Led", "Úno", "Bře", "Dub", "Kvě", "Čer", "Čvc", "Srp", "Zář", "Říj", "Lis", "Pro"],
  short_day_names: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"]
});