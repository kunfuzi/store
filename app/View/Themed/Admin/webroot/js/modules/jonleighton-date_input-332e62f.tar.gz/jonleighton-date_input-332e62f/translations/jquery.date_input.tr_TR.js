jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Ocak", "Şubat", "Mart", "Nisanl", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"],
  short_month_names: ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Ekim", "Kas", "Ara"],
  short_day_names: ["Pzr", "Pzt", "Sal", "Çrş", "Prş", "Cum", "Cmt"]
});
