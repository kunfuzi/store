jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"],
  short_month_names: ["Ian", "Feb", "Mar", "Apr", "Mai", "Iun", "Iul", "Aug", "Sep", "Oct", "Noi", "Dec"],
  short_day_names: ["Dum", "Lu", "Ma", "Mie", "Joi", "Vin", "Sam"]
});
