jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
  short_month_names: ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"],
  short_day_names: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"]
});
