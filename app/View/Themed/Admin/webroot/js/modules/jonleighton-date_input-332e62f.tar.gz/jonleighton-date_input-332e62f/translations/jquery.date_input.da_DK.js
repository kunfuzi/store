jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December"],
  short_month_names: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"],
  short_day_names: ["Sø", "Ma", "Ti", "On", "To", "Fr", "Lø"]
});
