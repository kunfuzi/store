jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Jaanuar", "Veebruar", "Märts", "Aprill", "Mai", "Juuni", "Juuli", "August", "September", "Oktoober", "November", "Detsember"],
  short_month_names: ["jaan", "veebr", "märts", "apr", "mai", "juuni", "juuli", "aug", "sept", "okt", "nov", "dets"],
  short_day_names: ["P", "E", "T", "K", "N", "R", "L"]
});
