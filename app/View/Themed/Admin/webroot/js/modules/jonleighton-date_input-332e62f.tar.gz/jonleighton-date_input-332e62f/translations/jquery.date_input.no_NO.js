jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Janaur", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"],
  short_month_names: ["jan", "feb", "mar", "apr", "mai", "jun", "jul", "aug", "sep", "okt", "nov", "des"],
  short_day_names: ["sø","ma","ti", "on", "to", "fr", "lø"]
});
