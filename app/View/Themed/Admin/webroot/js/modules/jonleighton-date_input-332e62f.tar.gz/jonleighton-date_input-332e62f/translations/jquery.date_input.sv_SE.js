$.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December"],
  short_month_names: ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"],
  short_day_names: ["sön", "mån", "tis", "ons", "tor", "fre", "lör"]
});
