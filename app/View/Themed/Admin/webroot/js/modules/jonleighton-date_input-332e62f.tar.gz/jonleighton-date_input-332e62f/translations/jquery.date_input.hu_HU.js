jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Január", "Február", "Március", "Április", "Május", "Június", "Július", "Augusztus", "Szeptember", "Október", "November", "December"],
  short_month_names: ["Jan", "Febr", "Márc", "Ápr", "Máj", "Jún", "Júl", "Aug", "Szept", "Okt", "Nov", "Dec"],
  short_day_names: ["V", "H", "K", "SZ", "CS", "P", "SZ"]
});
