NAME = "Date Input"
VERSION = "1.2.1"
JQUERY = ">= 1.2.6"
