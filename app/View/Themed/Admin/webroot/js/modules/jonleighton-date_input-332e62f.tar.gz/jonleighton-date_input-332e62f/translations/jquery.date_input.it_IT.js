jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
  short_month_names: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
  short_day_names: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"]
});
