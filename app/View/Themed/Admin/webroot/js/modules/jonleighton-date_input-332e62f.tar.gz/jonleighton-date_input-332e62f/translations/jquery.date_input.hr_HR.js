jQuery.extend(DateInput.DEFAULT_OPTS, {
  month_names: ["Sijećanj", "Veljača", "Ožujak", "Travanj", "Svibanj", "Lipanj", "Srpanj", "Kolovoz", "Rujan", "Listopad", "Studeni", "Prosinac"],
  short_month_names: ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"],
  short_day_names: ["Ned", "Pon", "Uto", "Sri", "Čet", "Pet", "Sub"]
});
